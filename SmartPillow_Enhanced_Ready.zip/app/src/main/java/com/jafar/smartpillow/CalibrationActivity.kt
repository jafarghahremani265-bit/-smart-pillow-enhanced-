package com.jafar.smartpillow

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.os.VibrationEffect
import android.os.Vibrator

class CalibrationActivity:AppCompatActivity(),BreathDetector.Callback{
 private lateinit var detector:BreathDetector;private lateinit var bar:ProgressBar;private lateinit var readings:TextView;private lateinit var result:TextView
 private val vals=mutableListOf<Double>();private val handler=Handler(Looper.getMainLooper());private var done=false
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_calibration);bar=findViewById(R.id.calibration_bar);readings=findViewById(R.id.readings);result=findViewById(R.id.result)
  findViewById<Button>(R.id.test_vibration).setOnClickListener{(getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(500,160))}
  findViewById<Button>(R.id.save_threshold).setOnClickListener{val t=(vals.filter{it>0}.average().takeIf{it.isFinite()}?:200.0)*2.5;getSharedPreferences("settings",0).edit().putInt("threshold",t.toInt().coerceAtLeast(100)).apply();Toast.makeText(this,"آستانه ذخیره شد",Toast.LENGTH_SHORT).show();finish()}
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){result.text="ابتدا مجوز میکروفون را در صفحهٔ اصلی بدهید.";return}
  detector=BreathDetector(this,{32768.0},{60000},this);try{detector.start();handler.postDelayed({finishCalibration()},60000)}catch(e:Exception){result.text="راه‌اندازی میکروفون ناموفق بود: ${e.localizedMessage}"}
 }
 override fun onLevel(rms:Double,accelDelta:Double,isBreath:Boolean){runOnUiThread{vals.add(rms);if(vals.size>500)vals.removeAt(0);bar.progress=rms.toInt().coerceIn(0,32767)*100/32767;readings.text="کمینه: ${vals.minOrNull()?.toInt()?:0}  میانگین: ${vals.average().toInt()}  بیشینه: ${vals.maxOrNull()?.toInt()?:0}"}}
 override fun onApnea(silenceMs:Long){};override fun onBreathResumed(apneaDurationMs:Long){}
 private fun finishCalibration(){if(done)return;done=true;detector.stop();val quiet=detector.noiseFloor.takeIf{it>0}?:vals.filter{it>0}.average().takeIf{it.isFinite()}?:100.0;val t=(quiet*2.5).toInt().coerceAtLeast(100);result.text="کالیبراسیون پایان یافت. آستانهٔ پیشنهادی: $t (حدود ۲٫۵ برابر نویز آرام)"}
 override fun onDestroy(){if(::detector.isInitialized)detector.stop();handler.removeCallbacksAndMessages(null);super.onDestroy()}
}
