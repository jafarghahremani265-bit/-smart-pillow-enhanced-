package com.jafar.smartpillow

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.ToneGenerator
import android.media.AudioManager
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

class MonitorService : Service(), BreathDetector.Callback {
    private var detector: BreathDetector?=null
    private var wakeLock: PowerManager.WakeLock?=null
    private lateinit var logger: EventLogger
    private var stage=0
    private var apneaStart=0L
    private var lastNoise=0L
    private val escalation=Handler(Looper.getMainLooper())
    private val advance=Runnable { if(stage==1) stimulate(2) else if(stage==2) stimulate(3) }
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_ALARM,80) }
    override fun onCreate(){super.onCreate();logger=EventLogger(this);createChannel()}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_STOP){stopSelf();return START_NOT_STICKY}
        startForeground(NOTIFY_ID,notification())
        try { if(detector==null){wakeLock=(getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"SmartPillow:Monitor").also{it.acquire()};detector=BreathDetector(this,{getSharedPreferences("settings",0).getInt("threshold",500).toDouble()},{getSharedPreferences("settings",0).getInt("timeout",12)*1000L},this).also{it.start()} } }
        catch(e:Exception){send("ERROR",e.message?:"Microphone error");stopSelf()}
        return START_STICKY
    }
    override fun onLevel(rms:Double,accelDelta:Double,isBreath:Boolean){send("LEVEL","$rms,$accelDelta,$isBreath");val now=System.currentTimeMillis();if(now-lastNoise>60000){logger.noise(detector?.noiseFloor?:0.0);lastNoise=now}}
    override fun onApnea(silenceMs:Long){apneaStart=System.currentTimeMillis();stage=0;stimulate(1);send("STATUS","وقفهٔ تنفسی؛ تحریک مرحلهٔ ۱")}
    override fun onBreathResumed(apneaDurationMs:Long){if(stage>0)logger.apnea(apneaDurationMs,stage,true);escalation.removeCallbacks(advance);stage=0;(getSystemService(VIBRATOR_SERVICE) as Vibrator).cancel();tone.stopTone();send("STATUS","تنفس دوباره شناسایی شد")}
    private fun stimulate(next: Int) {
        stage = next
        escalation.removeCallbacks(advance)
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val effect = when (next) {
                1 -> VibrationEffect.createWaveform(
                    longArrayOf(0, 900, 300, 900), intArrayOf(0, 255, 0, 255), -1
                )
                2 -> VibrationEffect.createWaveform(
                    longArrayOf(0, 1200, 300, 1200, 300, 1200), intArrayOf(0, 255, 0, 255, 0, 255), -1
                )
                else -> VibrationEffect.createWaveform(
                    longArrayOf(0, 1600, 300, 1600, 300, 1600), intArrayOf(0, 255, 0, 255, 0, 255), 0
                )
            }
            vibrator.vibrate(effect)
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(when (next) {
                1 -> longArrayOf(0, 900, 300, 900)
                2 -> longArrayOf(0, 1200, 300, 1200, 300, 1200)
                else -> longArrayOf(0, 1600, 300, 1600, 300, 1600)
            }, if (next >= 3) 0 else -1)
        }

        when (next) {
            1 -> escalation.postDelayed(advance, 5_000)
            2 -> {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 500)
                escalation.postDelayed(advance, 5_000)
            }
            else -> tone.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 5_000)
        }
    }
    private fun notification():Notification {val stop=PendingIntent.getService(this,1,Intent(this,MonitorService::class.java).setAction(ACTION_STOP),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);return NotificationCompat.Builder(this,"monitor").setSmallIcon(R.drawable.ic_notification).setContentTitle(getString(R.string.notification_title)).setContentText("پایش تنفس در حال اجراست").setOngoing(true).addAction(0,"توقف",stop).build()}
    private fun createChannel(){if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("monitor",getString(R.string.channel_name),NotificationManager.IMPORTANCE_LOW))}
    private fun send(type:String,value:String){sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra("type",type).putExtra("value",value))}
    override fun onDestroy(){if(stage>0)logger.apnea((System.currentTimeMillis()-apneaStart).coerceAtLeast(0),stage,false);escalation.removeCallbacks(advance);(getSystemService(VIBRATOR_SERVICE) as Vibrator).cancel();detector?.stop();detector=null;if(wakeLock?.isHeld==true)wakeLock?.release();tone.release();super.onDestroy()}
    override fun onBind(intent:Intent?)=null
    companion object {const val ACTION_UPDATE="com.jafar.smartpillow.UPDATE";const val ACTION_STOP="com.jafar.smartpillow.STOP";const val NOTIFY_ID=42}
}
