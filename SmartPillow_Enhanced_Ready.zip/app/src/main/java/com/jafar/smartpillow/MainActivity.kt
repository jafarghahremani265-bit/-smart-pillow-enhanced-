package com.jafar.smartpillow

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider

class MainActivity:AppCompatActivity(){
 private lateinit var status:TextView;private lateinit var level:TextView;private lateinit var seek:SeekBar;private lateinit var timeout:Spinner
 private val prefs by lazy{getSharedPreferences("settings",0)}
 private val receiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){val type=i?.getStringExtra("type")?:return;val v=i.getStringExtra("value")?:"";runOnUiThread{when(type){"LEVEL"->{val p=v.split(",");if(p.size>=2)level.text="RMS: ${p[0].toDoubleOrNull()?.toInt()?:0}    حرکت: ${p[1].toDoubleOrNull()?.let{"%.2f".format(it)}?:"0"}"};"STATUS","ERROR"->status.text=v}}}}
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_main);status=findViewById(R.id.status);level=findViewById(R.id.level);seek=findViewById(R.id.sensitivity);timeout=findViewById(R.id.timeout)
  val values=listOf("۱۰ ثانیه","۱۲ ثانیه","۱۵ ثانیه","۲۰ ثانیه");timeout.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,values);val tv=prefs.getInt("timeout",12);timeout.setSelection(listOf(10,12,15,20).indexOf(tv).coerceAtLeast(0));timeout.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:android.widget.AdapterView<*>?){};override fun onItemSelected(p:android.widget.AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){prefs.edit().putInt("timeout",listOf(10,12,15,20)[pos]).apply()}}
  seek.max=100;seek.progress=(prefs.getInt("threshold",500)-100).coerceIn(0,1900)/20;seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){prefs.edit().putInt("threshold",100+p*20).apply()};override fun onStartTrackingTouch(s:SeekBar?){};override fun onStopTrackingTouch(s:SeekBar?) {}})
  findViewById<Button>(R.id.start).setOnClickListener{if(permissionsOk()) startMonitor() else requestPermissions()};findViewById<Button>(R.id.stop).setOnClickListener{stopService(Intent(this,MonitorService::class.java));status.text="پایش متوقف شد"}
  findViewById<Button>(R.id.calibrate).setOnClickListener{startActivity(Intent(this,CalibrationActivity::class.java))};findViewById<Button>(R.id.export).setOnClickListener{shareLog()}
 }
 private fun permissionsOk()=ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED && (Build.VERSION.SDK_INT<33||ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)
 private fun requestPermissions(){val list=mutableListOf(Manifest.permission.RECORD_AUDIO);if(Build.VERSION.SDK_INT>=33)list.add(Manifest.permission.POST_NOTIFICATIONS);ActivityCompat.requestPermissions(this,list.toTypedArray(),7)}
 override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){super.onRequestPermissionsResult(requestCode,permissions,grantResults);if(permissionsOk())startMonitor()else Toast.makeText(this,"برای پایش، دسترسی میکروفون و اعلان لازم است.",Toast.LENGTH_LONG).show()}
 private fun startMonitor(){try{ContextCompat.startForegroundService(this,Intent(this,MonitorService::class.java));status.text="پایش در حال اجراست"}catch(e:Exception){status.text="شروع پایش ناموفق بود: ${e.localizedMessage}"}}
 private fun shareLog(){try{val uri=FileProvider.getUriForFile(this,"$packageName.fileprovider",EventLogger(this).getFile());startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),"اشتراک‌گذاری گزارش"))}catch(e:Exception){Toast.makeText(this,"ساخت گزارش ناموفق بود",Toast.LENGTH_SHORT).show()}}
 override fun onStart(){super.onStart();ContextCompat.registerReceiver(this,receiver,IntentFilter(MonitorService.ACTION_UPDATE),ContextCompat.RECEIVER_NOT_EXPORTED)}
 override fun onStop(){unregisterReceiver(receiver);super.onStop()}
}
