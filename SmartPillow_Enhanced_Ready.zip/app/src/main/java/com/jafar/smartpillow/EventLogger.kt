package com.jafar.smartpillow

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EventLogger(context: Context) {
    private val file = File(context.getExternalFilesDir(null) ?: context.filesDir, "smartpillow_log.csv")
    private val lock = Any()
    private val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS", Locale.US)
    init { synchronized(lock) { if (!file.exists()) file.writeText("timestamp,type,duration_ms,stage,resolved,value\n") } }
    fun apnea(duration: Long, stage: Int, resolved: Boolean) = append("apnea,$duration,$stage,$resolved,")
    fun noise(value: Double) = append("noise_floor,,,,${"%.3f".format(Locale.US,value)}")
    private fun append(row: String) { synchronized(lock) { file.appendText("${fmt.format(Date())},$row\n") } }
    fun getFile(): File = file
}
