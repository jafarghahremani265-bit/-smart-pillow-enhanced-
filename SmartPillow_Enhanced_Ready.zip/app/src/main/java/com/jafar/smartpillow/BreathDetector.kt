package com.jafar.smartpillow

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt
import kotlin.math.abs

class BreathDetector(private val context: Context, private val threshold: () -> Double, private val timeoutMs: () -> Long, private val callback: Callback) {
    interface Callback { fun onLevel(rms: Double, accelDelta: Double, isBreath: Boolean); fun onApnea(silenceMs: Long); fun onBreathResumed(apneaDurationMs: Long) }
    @Volatile private var running=false
    private var recorder: AudioRecord?=null
    private var worker: Thread?=null
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    @Volatile private var accelDelta=0.0
    private var lastMagnitude=SensorManager.GRAVITY_EARTH
    @Volatile private var lastBreath=System.currentTimeMillis()
    @Volatile private var apneaReported=false
    @Volatile var noiseFloor=0.0; private set
    private val listener=object: SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) { val mag=sqrt(e.values[0]*e.values[0]+e.values[1]*e.values[1]+e.values[2]*e.values[2]); accelDelta=abs(mag-lastMagnitude); lastMagnitude=mag }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    @Synchronized fun start() {
        if(running) return
        val min=AudioRecord.getMinBufferSize(16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(min<=0) throw IllegalStateException("AudioRecord unavailable")
        val rec=AudioRecord(MediaRecorder.AudioSource.MIC,16000,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,maxOf(min,4096))
        if(rec.state!=AudioRecord.STATE_INITIALIZED){rec.release();throw IllegalStateException("Microphone initialization failed")}
        recorder=rec;running=true;lastBreath=System.currentTimeMillis();rec.startRecording()
        sensor?.let { sm.registerListener(listener,it,SensorManager.SENSOR_DELAY_NORMAL) }
        worker=Thread { val data=ShortArray(1024); var quiet=0.0
            while(running) { val n=try{rec.read(data,0,data.size)}catch(_:Exception){-1}; if(n<=0){if(running) Thread.sleep(40);continue}
                var sum=0.0;for(i in 0 until n){val v=data[i].toDouble();sum+=v*v}; val rms=sqrt(sum/n)
                if(rms < maxOf(threshold()*1.5, 100.0)){quiet=if(quiet==0.0)rms else quiet*0.95+rms*0.05;noiseFloor=quiet}
                val breath=rms>threshold() || accelDelta>0.18
                if(breath){val now=System.currentTimeMillis();if(apneaReported){callback.onBreathResumed(now-lastBreath);apneaReported=false};lastBreath=now}
                callback.onLevel(rms,accelDelta,breath)
                val silence=System.currentTimeMillis()-lastBreath
                if(silence>=timeoutMs() && !apneaReported){apneaReported=true;callback.onApnea(silence)}
            }
        }.also{it.name="SmartPillowAudio";it.start()}
    }
    @Synchronized fun stop(){if(!running)return;running=false;sm.unregisterListener(listener);try{recorder?.stop()}catch(_:Exception){};try{worker?.join(700)}catch(_:InterruptedException){Thread.currentThread().interrupt()};recorder?.release();recorder=null;worker=null}
}
